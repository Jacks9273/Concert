<?PHP

// define("NOTIFICATION_TABLE", TABLE_PREFIX."notification");
// define("EMAIL__TABLE", TABLE_PREFIX . "email");
// define("SMTP_SERVER", 'XYZ');

// define("EMAIL_CONFIG_FROM", 'system@mg.tik.co');
