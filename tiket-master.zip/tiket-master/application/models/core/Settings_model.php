<?PHP

class Settings_model {

}