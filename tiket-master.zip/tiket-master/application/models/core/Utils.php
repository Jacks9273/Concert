<?PHP


function generateRandomString()
{

}

function generateRandomPIN($length)
{

}

