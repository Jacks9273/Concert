<?PHP

class Storage_model {

}