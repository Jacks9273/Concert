<?PHP

class Language_model {

}