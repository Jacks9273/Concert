<li><a href="<?= BASE_URL ?>user/dashboard"> <i class="fa fa-home"></i>Dashboard </a></li>
<li><a href="<?= BASE_URL ?>tickets/create_new"> <i class="fa fa-ticket"></i>New Ticket </a></li>
<li><a href="<?= BASE_URL ?>tickets/my_tickets"> <i class="fa fa-list"></i>My Tickets </a></li>
<li><a href="<?= BASE_URL ?>user/profile"> <i class="fa fa-user"></i>Profile </a></li>