<!-- /info alert -->
<?php get_msg(); ?>

<div class="container-fluid">
	<!-- Content area -->
	<div class="content">
		<div class="row">
			<div class="offset-md-4 col-md-4">
				<!-- Profile info -->
				<div class="card">
					<div class="card-header bg-transparent header-elements-inline">
						<h5 class="card-title">Re-activate by PIN</h5>
					</div>
					<div class="card-body">
						<form method='post' action='' enctype="multipart/form-data">
							
							<label class=" control-label">Insert PIN<code>*</code></label>
							<input type="text" name="pin" class="form-control loan-object" required>
								
							<br>
							<input type="submit" name="validate" class="btn btn-primary btn-block" value='CLick to validate' >
						</form>
					</div>
					
				</div>
				<!-- /profile info -->
			</div>


			

		</div>
		<!-- /content area -->
	</div>
</div>
