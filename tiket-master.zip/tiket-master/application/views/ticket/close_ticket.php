<!-- Dashboard Counts Section-->
<section class="forms">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">

                    <div class="card-header d-flex align-items-center">
                        <h3 class="h4">Ticket Number: <?= $ticket_no ?></h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 table-responsiveW">
                                <?php
                                echo $message;
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>