
        <!-- JavaScript files-->
        <script src="<?= BASE_URL ?>assets/vendor/jquery/jquery.min.js"></script>
        <script src="<?= BASE_URL ?>assets/vendor/popper.js/umd/popper.min.js"> </script>
        <script src="<?= BASE_URL ?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?= BASE_URL ?>assets/vendor/jquery.cookie/jquery.cookie.js"> </script>
        <script src="<?= BASE_URL ?>assets/vendor/chart.js/Chart.min.js"></script>
        <script src="<?= BASE_URL ?>assets/vendor/jquery-validation/jquery.validate.min.js"></script>
        <!-- Main File-->
        <script src="<?= BASE_URL ?>assets/js/front.js"></script>
    </body>
</html>