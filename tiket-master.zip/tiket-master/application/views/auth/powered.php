<div class="form-group">
	<div style="color:black; margin-bottom: -20px;">
		<?php	if(!DISABLE_POWERED_BY) {	?>
			<b style="color:#5d5d5d">Powered by</b> <img src="<?= BASE_URL, DEV_COMPANY_LOGO ?>"
														 class="align-middle pb-1" alt="Calcun"
														 width="15px"><a
				href="<?php echo DEV_COMPANY_URL ?>"
				target="_blank"><?php echo DEV_COMPANY_NAME ?></a>
		<?php }	?>
	</div>
</div>
